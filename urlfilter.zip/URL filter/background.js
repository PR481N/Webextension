// background.js


console.log("Service worker script loaded.");

self.addEventListener('fetch', function(event) {
  const url = event.request.url;

  // Retrieve stored URLs
  chrome.storage.local.get({ urls: [] }, function(result) {
    const urls = result.urls;
    urls.push(url);

    // Store the updated URLs list
    chrome.storage.local.set({ urls: urls });

    // Call the API with the current URL
    fetch('http://127.0.0.1:5000/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ urls: [url] })
    })
    .then(response => response.json())
    .then(data => {
      let result = data[0];
      chrome.browserAction.setBadgeText({ text: result === 'malicious' ? 'BAD' : 'GOOD' });
      chrome.browserAction.setBadgeBackgroundColor({ color: result === 'malicious' ? '#FF0000' : '#00FF00' });
    })
    .catch(error => {
      console.error('Error:', error);
    });
  });
});
  