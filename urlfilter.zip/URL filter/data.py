import pandas as pd
from sklearn.model_selection import train_test_split

def load_data(file_path):
    """
    Load dataset from a CSV file.
    
    :param file_path: str, path to the CSV file
    :return: DataFrame, the loaded dataset
    """
    df = pd.read_csv(file_path)
    return df

def preprocess_data(df):
    """
    Preprocess the dataset.
    
    :param df: DataFrame, the dataset
    :return: X, y - features and labels
    """
    X = df['url']
    y = df['result']
    return X, y

def split_data(X, y, test_size=0.2, random_state=42):
    """
    Split the dataset into training and testing sets.
    
    :param X: Series, features
    :param y: Series, labels
    :param test_size: float, the proportion of the dataset to include in the test split
    :param random_state: int, random state for reproducibility
    :return: X_train, X_test, y_train, y_test - split datasets
    """
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

if __name__ == "__main__":
    df = load_data('urls.csv')
    X, y = preprocess_data(df)
    X_train, X_test, y_train, y_test = split_data(X, y)
    print(f"Training data: {len(X_train)} samples")
    print(f"Testing data: {len(X_test)} samples")
