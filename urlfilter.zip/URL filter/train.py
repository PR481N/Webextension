from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score
import joblib
import data
print("Start training")
def train_model(X_train, y_train):
    """
    Train the model using a pipeline of TFIDF and RandomForest.
    
    :param X_train: Series, training features
    :param y_train: Series, training labels
    :return: trained model
    """
    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer()),
        ('clf', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    
    pipeline.fit(X_train, y_train)
    return pipeline

if __name__ == "__main__":
    print("ready")
    df = data.load_data('urls.csv')
    print("Next step")
    X, y = data.preprocess_data(df)
    X_train, X_test, y_train, y_test = data.split_data(X, y)
    print("again next")

    model = train_model(X_train, y_train)
    joblib.dump(model, 'url_classifier.pkl')
    print("final")

    # Evaluate the model
    y_pred = model.predict(X_test)
    print(f"Accuracy: {accuracy_score(y_test, y_pred)}")
