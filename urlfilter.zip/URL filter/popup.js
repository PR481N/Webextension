
document.addEventListener('DOMContentLoaded', function() {
  const urlList = document.getElementById('urlList');

  // Get current URL from the browser's address bar
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      const currentUrl = tabs[0].url;

      // Display the current URL in the list
      const listItem = document.createElement('p1');
      listItem.textContent = currentUrl;
      urlList.appendChild(listItem);

      // Call the API with the current URL
    fetch('http://127.0.0.1:5000/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ urls: [currentUrl] })
    })
    .then(response => response.json())
    .then(data => {
      let result = data[0];
      const statusItem = document.createElement('p');
      statusItem.textContent = `This URL may be ${result}`;
      urlList.appendChild(statusItem);
    })
    .catch(error => {
      console.error('Error:', error);
      const errorItem = document.createElement('p');
      errorItem.textContent = 'Error checking URL';
      urlList.appendChild(errorItem);
    });
  });
});
