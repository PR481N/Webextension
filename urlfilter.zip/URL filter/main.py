import joblib
import data

def predict_url(urls):
    """
    Predict whether URLs are benign or malicious.
    
    :param urls: list, URLs to predict
    :return: list, predictions
    """
    model = joblib.load('url_classifier.pkl')
    predictions = model.predict(urls)
    return predictions

if __name__ == "__main__":
    # Test the prediction on new URLs
    new_urls = ["https://www.msn.com/en-xl/feed?ocid=msedgntp&pc=ASTS&cvid=8a7b8d7d95c045b3a091a6013424ef73&ei=11", "https://technicalsagar.in/"]
    predictions = predict_url(new_urls)
    for url, pred in zip(new_urls, predictions):
        print(f"URL: {url} - Prediction: {'Malicious' if pred == 1 else 'Benign'}")
